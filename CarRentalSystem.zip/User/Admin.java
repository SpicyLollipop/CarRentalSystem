//package xxx;

//public class Admin extends User
//{
	
//}
